package com.pweb.tiendaonline.entities;

public enum Role {
    ADMIN,
    USER
}
