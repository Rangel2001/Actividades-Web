package com.pweb.tiendaonline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaOnlineApplicationTests {

    @Test
    void contextLoads() {
    }

}
